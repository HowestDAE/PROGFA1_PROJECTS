# DAE PROGFA ENGINE 2025-2026

The Programming for artists engine library was created to have an easy to use environment for the programming for artists 1 course in DAE, which fully prepares for the courses that follow in the third and fourth semester of the course.
This is the version used in academic year 25-26.

### CHANGES
A few changes were made since the first version used in 24-25:

## INSTALLATION

You can install ProgfaEngine using pip:
```bash
# First, download the install files:
dae_progfa_lib-1.0.1.tar.gz
dae_progfa_lib-1.0.1-py3-none-any.whl
```
```bash
# REPLACE <path> with the actual location of the mentioned .tar.gz and .whl file
#   make sure the path does not contain spaces or special characters!
pip install <path>/dae_progfa_lib-1.0.1-py3-none-any.whl
```

## USAGE
```bash
from dae_progfa_lib.templates import template
```
```bash
from dae_progfa_lib import *
```

## DOCUMENTATION
Coming soon...

## EXAMPLES
Coming soon...

## CHANGELOG
Changelog.md coming soon...