from math import trunc

import pygame
import math
import os
import re
from urllib.parse import urlparse  # image url check
import urllib.request  # image url check
from io import BytesIO  # image url check
from typing import List, Tuple
from enum import Enum

from .progfa_image import ProgfaImage
from pygame.math import Vector2


class MouseButton(Enum):
    NONE = 0
    LEFT = 1
    MIDDLE = 2
    RIGHT = 3
    SCROLL_UP = 4
    SCROLL_DOWN = 5
    SIDE_1 = 6
    SIDE_2 = 7


class ShapeMode(Enum):
    CENTER = 0
    CORNER = 1


class ProgfaEngine:
    """
    A class representing the programming for artists 1 engine, using pygame.
    """
    # v1.2.0 : not used
    # _frames = []  # Class variable, behaves like a static variable

    def __init__(self, width, height):
        self._background_color = pygame.Color(0, 0, 0, 255)  # v1.2.0 : pygame Color instead of tuple[float,float.float]
        self._outline_color = pygame.Color(255, 0, 255, 255)
        self._fill_color = pygame.Color(0, 255, 255, 255)

        self._shape_mode = ShapeMode.CORNER

        pygame.init()
        self._width = width
        self._height = height
        self._screen = pygame.display.set_mode([width, height])
        self._fps = 60

        self._mouse_x = 0
        self._mouse_y = 0
        self._mouse_pressed = False
        self._mouse_button = MouseButton.NONE

        self._key = None
        self._key_pressed = False

        self._clock = pygame.time.Clock()
        self._font_name = 'default'
        self._font_size = 20
        self._font_is_system = False
        self._font = pygame.font.Font(None, self._font_size)

        """v1.2.0 : removing UI elements
        _ui_manager = pygame_gui.UIManager((width, height))

        # Create a textbox
        self._text_input = pygame_gui.elements.UITextEntryLine(
            relative_rect=pygame.Rect([200, 200], [400, 50]),
            manager=_ui_manager
        )

        # Create a button
        self.button = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect([200, 300], [200, 50]),
            text="Click me!",
            manager=_ui_manager
        )

        self.ui_manager = _ui_manager
        """

        try:
            pygame.mouse.set_cursor(*pygame.cursors.diamond)
        except Exception:
            pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_ARROW)

    @property
    def width(self) -> int | float:
        """
        Returns the width of the window.
        """
        return self._width

    @width.setter
    def width(self, value: int | float):
        """
        Changes the width of the window.
        """
        self.set_resolution(value, self._height)
        self.background_color = self._background_color

    @property
    def height(self) -> int | float:
        """
        Returns the height of the window.
        """
        return self._height

    @height.setter
    def height(self, value: int | float):
        """
        Changes the height of the window.
        """
        self.set_resolution(self._width, value)
        self.background_color = self._background_color

    @property
    def fps(self) -> int:
        """
        Get the current frames per second that is being used as the speed of the game loop.
        """
        return self._fps

    @fps.setter
    def fps(self, value: int):
        """
        Changes the speed of the game loop by changing the frames per second.
        """
        self._fps = value

    def set_fps(self, fps: int):
        """
        Changes the speed of the game loop by changing the frames per second.
        :param fps: frames per second
        """
        self._fps = fps

    @property
    def shape_mode(self):
        """Returns the current shape mode used to draw shapes from. 0 = ShapeMode.CENTER, 1 = ShapeMode.CORNER."""
        return self._shape_mode

    @shape_mode.setter
    def shape_mode(self, value: ShapeMode | int):
        """
        Defines if shapes will be drawn from their center point or top-left corner.
        ShapeMode.CENTER or ShapeMode.CORNER
        :Examples:
        >>> engine.shape_mode = ShapeMode.CENTER
        """
        assert value in (ShapeMode.CENTER, ShapeMode.CORNER, 0, 1), \
               "[ENGINE ERROR] shape_mode should be set to either ShapeMode.CENTER (0) or ShapeMode.CORNER (1)!"
        self._shape_mode = value if isinstance(value, ShapeMode) else ShapeMode(value)

    @property
    def mouse_x(self) -> float:
        """
        Get the current x-coordinate of the mouse.
        """
        return self._mouse_x

    @property
    def mouse_y(self) -> float:
        """
        Get the current y-coordinate of the mouse.
        """
        return self._mouse_y

    @property
    def mouse_pressed(self) -> bool:
        """
        Returns True if a mouse button is currently pressed, otherwise it returns False.
        """
        return self._mouse_pressed

    @property
    def mouse_button(self) -> MouseButton:
        """
        Returns the number of the mouse button that IS pressed (readonly).
        If no mouse button is pressed, this will return MouseButton.NONE.
        Possible return values: see MouseButton information.
        """
        return self._mouse_button

    @property
    def key_pressed(self) -> bool:
        """
        Returns True if a mouse button is currently pressed, otherwise it returns False.
        """
        return self._key_pressed

    @property
    def key(self) -> str | None:
        """
        Get the current key (code) that was pressed.
        If no mouse button is pressed, this will return None.
        """
        return self._key

    # v1.2.0 : replaced by property to be similar to mouse_pressed
    # def key_pressed(self) -> bool:
    #     """
    #     Returns True if a key is currently pressed, or False if no key is currently pressed.
    #     """
    #     return self._key_pressed

    def __getattr__(self, name):
        if hasattr(pygame.Surface, name):
            return getattr(self._screen, name)
        raise AttributeError(f"'ProgfaEngine' object has no attribute '{name}'")

    def set_title(self, title: str) -> None:
        """
        Changes the title displayed on top of your game window.
        :param title: The title to be displayed.
        """
        pygame.display.set_caption(title)


    def set_resolution(self, width: float, height: float) -> None:
        """
        Changes the window size.

        :param width: The new width of the window.
        :param height: The new height of the window.

        :Examples:
        >>> engine.set_resolution(500, 300)
        >>> engine.set_resolution(width=500, height=300)
        """
        self._width = width
        self._height = height
        self._screen = pygame.display.set_mode([width, height])

    # endregion Shape mode

    def _get_coordinates(self, x: float, y: float, width: float, height: float) -> pygame.math.Vector2:
        """
        Engine helper function, translates coordinates to top left based on shape mode.
        """
        if self._shape_mode == ShapeMode.CENTER:
            return Vector2(x - width / 2, y - height / 2)
        else:
            return Vector2(x, y)

    # endregion Shape mode

    # region Colors

    @property
    def transparency(self) -> float:
        """
        Returns the transparency component of the fill color.
        :raises ValueError: If no color is set (fill color is None).
        """
        return self._fill_color.a / 255.0

    @transparency.setter
    def transparency(self, value: float | int):
        """
        Changes the transparency value of the fill color. Give a decimal percentage (value between 0.0 and 1.0).
        """
        if self._fill_color is None:
            self._fill_color = pygame.Color(0, 0, 0)
        # Ensure the value is within the valid range (0.0 - 1.0)
        value = max(0.0, min(1.0, float(value)))
        self._fill_color.a = int(value * 255)

    @property
    def color(self) -> Tuple[float, float, float, float] | None:
        """
        Returns the fill color as a tuple of RGBA components.
        """
        if self._fill_color is None:
            return None
        r = self._fill_color.r / 255.0
        g = self._fill_color.g / 255.0
        b = self._fill_color.b / 255.0
        a = self._fill_color.a / 255.0
        return r, g, b, a

    # v1.2.0 : allow hex string as well
    @color.setter
    def color(self, value: Tuple[float, float, float] | Tuple[float, float, float, float] | str | None):
        """
        Changes the fill color based on a tuple of RGB or RGBA components, or a hexadecimal string (e.g. "FF0000").
        In case of RGB(A), ensure decimal percentages for each value (values between 0.0 and 1.0).
        Choose None to remove the fill (color) for following shapes.

        :Examples:
        >>> engine.color = None                 # removes the fill color
        >>> engine.color = "FF0000"             # color_r = 1, color_g = 0, color_b = 0 (fully opaque)
        >>> engine.color = (1, 0.2, 0)          # color_r = 1, color_g = 0.2, color_b = 0 (fully opaque)
        >>> engine.color = (1, 0.2, 0, 0.5)     # color_r = 1, color_g = 0.2, color_b = 0, transparency = 0.5
        """
        if value is None:
            self._fill_color = None
            return
        elif isinstance(value, str):
            self._fill_color = self._hex_to_rgb(value)
            r, g, b, alpha = value
        elif len(value) == 3:
            r, g, b = value
            alpha = 1.0  # Default alpha value
        elif len(value) == 4:
            r, g, b, alpha = value
        else:
            raise ValueError("Invalid input tuple. Use (R, G, B) or (R, G, B, A), or a hexadecimal STR value (#FF0000).")

        # Ensure the RGB values are within the valid range (0.0 - 1.0)
        r = max(0.0, min(1.0, r))
        g = max(0.0, min(1.0, g))
        b = max(0.0, min(1.0, b))
        a = max(0.0, min(1.0, alpha))
        self._fill_color = pygame.Color(0, 0, 0)
        self._fill_color.r = int(r * 255)
        self._fill_color.g = int(g * 255)
        self._fill_color.b = int(b * 255)
        self._fill_color.a = int(a * 255)

    @property
    def background_color(self) -> Tuple[float, float, float]:
        """
        Gets the current background color of the window (r, g, b).
        :return: current background color
        """
        r = self._background_color.r / 255.0
        g = self._background_color.g / 255.0
        b = self._background_color.b / 255.0
        return r, g, b

    @background_color.setter
    def background_color(self, value: Tuple[float, float, float]):
        """
        Changes the background color based on a tuple of RGB components.
        Ensure these are decimal percentages (values between 0.0 and 1.0).
        If you include an alpha value for transparency, it will be ignored.
        None will result in a black background color.
        :Examples:
        >>> engine.background_color = (1, 0.2, 0)
        """
        if value is None:
            r, g, b, alpha = 0, 0, 0, 1
        elif len(value) == 3:
            r, g, b = value
            alpha = 1.0  # Default alpha value
        elif len(value) == 4:
            r, g, b, alpha = value
        else:
            raise ValueError("Invalid input tuple. Use (R, G, B) for background color.")

        # Ensure the RGB values are within the valid range (0.0 - 1.0)
        r = max(0.0, min(1.0, r))
        g = max(0.0, min(1.0, g))
        b = max(0.0, min(1.0, b))
        a = max(0.0, min(1.0, alpha))
        self._background_color = pygame.Color(int(r * 255), int(g * 255), int(b * 255), int(a * 255))
        self._background_color = pygame.Color(int(r * 255), int(g * 255), int(b * 255))
        self._screen.fill(self._background_color[:3])

        if value is None:
            return
        elif len(value) == 3:
            r, g, b = value
            alpha = 1.0  # Default alpha value
        elif len(value) == 4:
            r, g, b, alpha = value
        else:
            raise ValueError("Invalid input tuple for background. Use (R, G, B) or (R, G, B, A).")


    # v1.2.0 : property instead of function
    @property
    def has_outline(self) -> bool:
        """
        Readonly property. Checks if the object has a stroke color (True) or not (False).
        Will return False after setting outline color to None.
        """
        return self._outline_color is not None and self._outline_color != (None, None, None)

    # v1.2.0 : property instead of function
    @property
    def has_fill(self) -> bool:
        """
        Readonly property. Checks if the object has a fill color (True) or not (False).
        Will return False after setting color to None.
        """
        return self._fill_color is not None and self._fill_color != (None, None, None)

    @property
    def outline_color(self) -> Tuple[float, float, float] | None:
        """
        Returns the outline color as a tuple of RGBA components, or None if there is currently no outline.
        """
        if self._outline_color is None:
            return None
        r = self._outline_color.r / 255.0
        g = self._outline_color.g / 255.0
        b = self._outline_color.b / 255.0
        return r, g, b

    @outline_color.setter
    def outline_color(self, value: Tuple[float, float, float] | None):
        """
        Changes the outline color based on a tuple of RGB components.
        Ensure these are decimal percentages (values between 0.0 and 1.0).
        Choose None to remove the outline for following shapes.

        :Examples:
        >>> engine.outline_color = None             # removes the fill color
        >>> engine.outline_color = (1, 0.2, 0)      # outline_color_r = 1, outline_color_g = 0.2, outline_color_b = 0
        """
        if value is None:
            self._outline_color = None
            return
        elif len(value) == 3:
            r, g, b = value
        else:
            raise ValueError("Invalid input tuple. Use (R, G, B) for outline colors, or None to remove it.")

        # Ensure the RGB values are within the valid range (0.0 - 1.0)
        r = max(0.0, min(1.0, r))
        g = max(0.0, min(1.0, g))
        b = max(0.0, min(1.0, b))
        self._outline_color = pygame.Color(0, 0, 0)
        self._outline_color.r = int(r * 255)
        self._outline_color.g = int(g * 255)
        self._outline_color.b = int(b * 255)

    # endregion Colors

    # region Color helpers

    # v1.2.0 : moved inside class, static method
    @staticmethod
    def _hex_to_rgb(hex_color: str) -> Tuple[int, int, int, int]:
        """
        *Engine helper function, advised not to use this function.*
        Accepts 6-digit RGB or 8-digit RGBA hex values as a str.
        """
        assert isinstance(hex_color, str), '[ENGINE ERROR] hex_color should be a string (e.g. "#FF0000")!'

        hex_value = hex_color.lstrip('#')
        length = len(hex_value)

        assert length in (6, 8), "[ENGINE ERROR] Hex color must have 6 or 8 digits (e.g. #FF0000 or #FF000080)"
        assert re.fullmatch(r'[0-9A-Fa-f]{6,8}', hex_value), "[ENGINE ERROR] Invalid hex characters"

        r = int(hex_value[0:2], 16)
        g = int(hex_value[2:4], 16)
        b = int(hex_value[4:6], 16)
        a = int(hex_value[6:8], 16) if length == 8 else 255

        return r, g, b, a

    @staticmethod
    def _is_decimal_percentage(value) -> bool:
        """
        *Engine helper function, advised not to use this function.*\n
        """
        if not isinstance(value, (float, int)):
            return False
        if not 0 <= value <= 1:
            return False
        return True

    # endregion Color helpers

    # region Draw basic shapes

    def draw_dot(self, x: int | float, y: int | float, outline_width: int = 1) -> None:
        """
        Draws a dot in position (x, y).
        The size of the dot is determined by the stroke width.
        Uses the current stroke color.

        :param x: The x-coordinate of the dot.
        :param y: The y-coordinate of the dot.
        :param outline_width: Optional. The stroke width to draw the dot (bigger stroke = bigger dot).
                             Defaults to 1.

        :return: 

        Examples:
        >>> engine.draw_dot(20, 30)       # uses stroke size 1
        >>> engine.draw_dot(20, 30, 4)    # uses stroke size 4
        """
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.circle(self._screen, self._outline_color, (x, y), outline_width)

    def draw_circle(self, x: int | float, y: int | float, diameter: int | float,
                    outline_width: int = 1) -> None:
        """
        Draws a circle in position x, y, using diameter for dimensions (width = height = size).
        To change if position is CENTER or top left CORNER, use the .shape_mode property (default = center).

        :param x: The x position of the circle (center or top left, determined by shape mode).
        :param y: The y position of the circle (center or top left, determined by shape mode).
        :param diameter: The diameter (width/height) of the circle.
        :param outline_width: Optional (default = 1). The stroke width to use around your circle.

        :return: 

        Examples:
        >>> engine.draw_ellipse(20, 30, 200, 100)       # Circle in pos 20, 30, size 200x100, stroke 1
        >>> engine.draw_ellipse(20, 30, 200, 100, 4)    # Circle in pos 20, 30, size 200x100, stroke 4
        """
        self.draw_ellipse(x, y, diameter, diameter, outline_width)

    def draw_ellipse(self, x: int | float, y: int | float,
                     width: int | float, height: int | float, outline_width: int = 1) -> None:
        """
        Draws an ellipse in position x, y, using dimensions width, height.
        To change if position is CENTER or top left CORNER, use the .shape_mode property (default = center).

        :param x: The x position of the ellipse (center or top left, determined by shape mode).
        :param y: The y position of the ellipse (center or top left, determined by shape mode).
        :param width: The width of the ellipse.
        :param height: The height of the ellipse.
        :param outline_width: Optional (default = 1). The stroke width to use around your ellipse.

        :return: 

        Examples:
        >>> engine.draw_ellipse(20, 30, 200, 100)       # ellipse in pos 20, 30, size 200x100, stroke 1
        >>> engine.draw_ellipse(20, 30, 200, 100, 4)    # ellipse in pos 20, 30, size 200x100, stroke 4
        """

        # v1.2.0 : Also accept negative width / height
        x, y, width, height = self._normalize_rect_coordinates(x, y, width, height)

        coordinates = self._get_coordinates(x, y, width, height)
        rect = pygame.Rect(coordinates.x, coordinates.y, width, height)
        if self.has_fill:
            fill_surface = pygame.Surface(rect.size, pygame.SRCALPHA)
            pygame.draw.ellipse(fill_surface, self._fill_color, fill_surface.get_rect())
            self._screen.blit(fill_surface, (coordinates.x, coordinates.y))
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.ellipse(self._screen, self._outline_color, rect, outline_width)

    @staticmethod
    def _normalize_rect_coordinates(x: int | float, y: int | float, width: int | float, height: int | float):
        """
        Helper function to normalize rectangle coordinates.
        :param height: height of the rectangle, can also be negative.
        :param width: width of the rectangle, can also be negative.
        :param x: x position (either center or top left)
        :param y: y position (either center or top left)
        :return: normalized rect
        """
        if width < 0:
            x += width
            width = -width
        if height < 0:
            y += height
            height = -height
        return x, y, width, height

    def draw_arc(self, x: int | float, y: int | float, width: int | float, height: int | float,
                 start_angle: int | float, end_angle: int | float, outline_width: int = 1) -> None:
        """
        Draws an arc in position x, y, using width, height for dimensions of the surrounding ellipse,
        and angles for the arc size.

        Change stroke/fill color or shape mode (default = center) using the engine functions.

        :param x: The x position of the rectangle (center or top left, determined by shape mode).
        :param y: The y position of the rectangle (center or top left, determined by shape mode).
        :param width: The width of the circle that surrounds the arc (width if arc would be a full ellipse).
        :param height: The height of the circle that surrounds the arc (height if arc would be a full ellipse).

        :param start_angle: The angle (in degrees) in which to start the arc.
        :param end_angle: The angle (in degrees) in which to end the arc; this is not the arc (angle) size!

        :param outline_width: Optional (default = 1). The stroke width to use around your arc.

        :return: 

        Examples:
        >>> # top part of an ellipse, stroke 1:
        >>> engine.draw_arc(20, 30, 200, 100, 180, 360)
        >>> # bottom part of an ellipse, stroke 4:
        >>> engine.draw_arc(20, 30, 200, 100, 0, 180, 4)
        """
        if height is None:
            height = width

        # v1.2.0 : Also accept negative width / height
        x, y, width, height = self._normalize_rect_coordinates(x, y, width, height)

        coordinates = self._get_coordinates(x, y, width, height)
        # rect = pygame.Rect(coordinates.x, coordinates.y, width, height)
        if self.has_fill:
            angle_range = end_angle - start_angle
            if angle_range < 0:
                angle_range += 360
            num_segments = int(angle_range / 3)  # Adjust the number of segments as desired

            # Calculate the angle step size for each triangle
            angle_step = math.radians((end_angle - start_angle) / num_segments)
            current_angle = math.radians(start_angle)

            # Iterate through the segments and draw triangles to approximate the filled arc
            for _ in range(num_segments):
                x1 = coordinates.x + width // 2
                y1 = coordinates.y + height // 2
                x2 = coordinates.x + width // 2 + int(math.cos(current_angle) * width / 2)
                y2 = coordinates.y + height // 2 + int(math.sin(current_angle) * height / 2)
                x3 = coordinates.x + width // 2 + int(math.cos(current_angle + angle_step) * width / 2)
                y3 = coordinates.y + height // 2 + int(math.sin(current_angle + angle_step) * height / 2)

                pygame.draw.polygon(self._screen, self._fill_color, [(x1, y1), (x2, y2), (x3, y3)])

                current_angle += angle_step
        # Draw the stroke of the arc
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            start_rad = math.radians(start_angle)
            end_rad = math.radians(end_angle)
            # pygame.draw.arc(self.screen, self.stroke_color, rect, start_rad, end_rad, 4)
            num_segments = int(abs(end_angle - start_angle) / 10)  # Adjust the number of segments as desired

            # Calculate the angle step size for each segment
            angle_step = math.radians((end_angle - start_angle) / num_segments)
            current_angle = math.radians(start_angle)

            center_x = coordinates.x + width // 2
            center_y = coordinates.y + height // 2

            # Iterate through the segments and draw lines to approximate the arc with a thicker stroke
            for _ in range(num_segments):
                start_x = center_x + int(math.cos(current_angle) * (width + 1) / 2)
                start_y = center_y + int(math.sin(current_angle) * (height + 1) / 2)
                end_x = center_x + int(math.cos(current_angle + angle_step) * (width + 1) / 2)
                end_y = center_y + int(math.sin(current_angle + angle_step) * (height + 1) / 2)

                pygame.draw.line(self._screen, self._outline_color, (start_x, start_y), (end_x, end_y), outline_width)

                current_angle += angle_step

            # Connect the stroke to the center
            start_x = center_x + int(math.cos(start_rad) * (width + 1) / 2)
            start_y = center_y + int(math.sin(start_rad) * (height + 1) / 2)
            end_x = center_x + int(math.cos(end_rad) * (width + 1) / 2)
            end_y = center_y + int(math.sin(end_rad) * (height + 1) / 2)
            pygame.draw.line(self._screen, self._outline_color, (center_x, center_y), (start_x, start_y), outline_width)
            pygame.draw.line(self._screen, self._outline_color, (center_x, center_y), (end_x, end_y), outline_width)

    def draw_square(self, x: int | float, y: int | float, size: int | float,
                    outline_width: int = 1) -> None:
        """
        Draws a square in position x, y, using size for dimensions (width=height=size).
        To change if position is CENTER or top left CORNER, use the .shape_mode property (default = center).
        :param x: The x position of the rectangle (center or top left, determined by shape mode).
        :param y: The y position of the rectangle (center or top left, determined by shape mode).
        :param size: The dimensions (width/height) of the square.
        :param outline_width: Optional (default = 1). The stroke width to use around your square.
        :return: 

        Examples:
        >>> engine.draw_square(20, 30, 200)     # stroke width 1
        >>> engine.draw_square(20, 30, 200, 4)  # stroke width 4
        >>> engine.draw_square(x=20, y=30, size=200)
        """
        self.draw_rectangle(x, y, size, size, outline_width)

    def draw_rectangle(self, x: int | float, y: int | float,
                       width: int | float, height: int | float, outline_width=1) -> None:
        """
        Draws a rectangle in position x, y, using dimensions width, height.
        To change if position is CENTER or top left CORNER, use the .shape_mode property (default = center).

        :param x: The x position of the rectangle (center or top left, determined by shape mode).
        :param y: The y position of the rectangle (center or top left, determined by shape mode).
        :param width: The width of the rectangle.
        :param height: The height of the rectangle.
        :param outline_width: Optional (default = 1). The stroke width to use around your rectangle.

        :return: 

        Examples:
        >>> engine.draw_rectangle(20, 30, 200, 100)                   # stroke 1
        >>> engine.draw_rectangle(20, 30, 200, 100, 4)                # stroke 4
        >>> engine.draw_rectangle(x=20, y=30, width=200, height=100)  # stroke 1
        """
        # v1.2.0 : Also accept negative width / height
        x, y, width, height = self._normalize_rect_coordinates(x, y, width, height)

        coordinates = self._get_coordinates(x, y, width, height)
        rect = pygame.Rect(coordinates.x, coordinates.y, width, height)
        if self.has_fill:
            fill_surface = pygame.Surface(rect.size, pygame.SRCALPHA)
            pygame.draw.rect(fill_surface, self._fill_color, fill_surface.get_rect())
            self._screen.blit(fill_surface, (coordinates.x, coordinates.y))
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.rect(self._screen, self._outline_color, rect, outline_width)

    def draw_triangle(self, x1: int | float, y1: int | float, x2: int | float, y2: int | float,
                      x3: int | float, y3: int | float, outline_width: int = 1) -> None:
        """
        Draws a triangle with the 3 (x,y) positions given. You can choose which is the first, second and third point;
        it makes no difference.

        :param x1: The x position of the FIRST point of your triangle.
        :param y1: The y position of the FIRST point of your triangle.
        :param x2: The x position of the SECOND point of your triangle.
        :param y2: The y position of the SECOND point of your triangle.
        :param x3: The x position of the THIRD point of your triangle.
        :param y3: The y position of the THIRD point of your triangle.
        :param outline_width: Optional (default = 1). The stroke width to use around your triangle.

        :return: 

        :Examples:
        >>> engine.color = 1, 0, 0                 # red fill
        >>> engine.draw_triangle(10, 10, 20, 50, 80, 100)  # triangle
        """
        vertices = [(x1, y1),
                    (x2, y2),
                    (x3, y3)]
        self.draw_poly(vertices, outline_width)

    def draw_quad(self, x1: int | float, y1: int | float, x2: int | float, y2: int | float,
                  x3: int | float, y3: int | float, x4: int | float, y4: int | float,
                  outline_width: int = 1) -> None:
        """
        Draws a quad with the four given x, y positions.
        The order of the arguments is the order in which they will be drawn. Quad is automatically closed.

        :param x1: The x position of the FIRST point of your quad.
        :param y1: The y position of the FIRST point of your quad.
        :param x2: The x position of the SECOND point of your quad.
        :param y2: The y position of the SECOND point of your quad.
        :param x3: The x position of the THIRD point of your quad.
        :param y3: The y position of the THIRD point of your quad.
        :param x4: The x position of the FOURTH point of your quad.
        :param y4: The y position of the FOURTH point of your quad.
        :param outline_width: Optional (default = 1). The stroke width to use around your quad.

        :return: 

        Examples:
        >>> engine.draw_quad(10, 10, 20, 50, 80, 100, 40, 30)     # stroke width 1
        >>> engine.draw_quad(10, 10, 20, 50, 80, 100, 40, 30, 4)  # stroke width 4
        """
        vertices = [(x1, y1),
                    (x2, y2),
                    (x3, y3),
                    (x4, y4)]
        self.draw_poly(vertices, outline_width)

    def draw_poly(self, vertices: List[Tuple[float, float]], outline_width: int = 1) -> None:
        """
        Draws a polygon with the given vertices.

        :param self: (ignore)
        :param vertices: List of (x,y) tuple combinations for every point of the shape.
            Format: [(x1,y1), (x2,y2), (x3,y3), (x4,y4), ...]
        :param outline_width: Optional (default = 1).
            The stroke width to use around your triangle.

        :return: 

        :Examples:
        >>> shape_vertices = [(10, 10), (20, 50), (80, 100), (40, 30)]
        >>> engine.draw_poly(shape_vertices)       # stroke width 1
        >>> engine.draw_poly(shape_vertices, 4)    # stroke width 4
        """
        if self.has_fill:
            min_x = min(vertices, key=lambda vertex: vertex[0])[0]
            max_x = max(vertices, key=lambda vertex: vertex[0])[0]
            min_y = min(vertices, key=lambda vertex: vertex[1])[1]
            max_y = max(vertices, key=lambda vertex: vertex[1])[1]
            width = max_x - min_x
            height = max_y - min_y
            fill_surface = pygame.Surface((width, height), pygame.SRCALPHA)
            adjusted_vertices = [(x - min_x, y - min_y) for x, y in vertices]
            pygame.draw.polygon(fill_surface, self._fill_color, adjusted_vertices)
            self._screen.blit(fill_surface, (min_x, min_y))
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.polygon(self._screen, self._outline_color, vertices, outline_width)

    def draw_line(self, x1: int | float, y1: int | float, x2: int | float, y2: int | float,
                  outline_width: int = 1) -> None:
        """
        Draws a line starting in position x1, y1, and ending in position x2, y2.
        Uses stroke color. WARNING: the line will not be visible if stroke color is unset/None.

        :param self: (ignore)
        :param x1: The x position of the first point of the line.
        :param y1: The y position of the first point of the line.
        :param x2: The x position of the second point of the line.
        :param y2: The y position of the second point of the line.
        :param outline_width: Optional (default = 1). The stroke width to draw your line.
            If 0, the line will not be visible.

        :return: 

        :Examples:
        >>> engine.draw_line(20, 30, 200, 100)       # draw a line from (20, 30) to (200, 100) with a stroke width of 1
        >>> engine.draw_line(20, 30, 200, 100, 4)    # draw a line from (20, 30) to (200, 100) with a stroke width of 4
        """

        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.line(self._screen, self._outline_color, (x1, y1), (x2, y2), outline_width)

    # endregion Draw basic shapes

    def take_screenshot(self, filename: str) -> None:
        """
        Takes a screenshot of the current game window and saves it.
        Supported file types are: ".png", ".jpg", ".jpeg", ".bmp", ".tga".
        Both TGA, and BMP file formats create uncompressed files.
        :param filename: the filename to use when saving the screenshot. The extension defines the format it will be
        saved in!
        :return: Nothing.
        """
        valid_extensions = {"png", "jpg", "jpeg", "bmp", "tga"}
        if not re.match(r".*\.[a-zA-Z]{3,4}$", filename):  # did they not provide an extension?
            filename = f"{filename}.png"  # png by default
        else:
            # Extract the extension (case-insensitive) and check if it's in valid extensions
            extension = filename.split('.')[-1].lower()
            if extension not in valid_extensions:
                raise ValueError(f"Unsupported file format: '{filename}' is not a valid image format.")

        # Ensure the screenshots directory exists
        screenshots_dir = "screenshots"
        if not os.path.exists(screenshots_dir):
            os.makedirs(screenshots_dir)

        # Save the screenshot in the screenshots directory
        filepath = os.path.join(screenshots_dir, filename)
        pygame.image.save(self._screen, filepath)
        print(f"-> Screenshot saved as {filepath}.")

    # region Text and fonts

    # v1.2.0 : added font size parameter
    def set_font(self, font: str, font_size: int = 20) -> None:
        """
        Sets the font that will be used when calling the draw_text function.

        :param font: either the name of a local file (extension .ttf or .otf), or a system font name (no extension)
        :param font_size: the size of the font to load (default 20)

        :Examples:
        >>> engine.set_font("example.ttf")            # Loads example.ttf, default font size 20
        >>> engine.set_font("example.ttf", 14)        # Loads example.ttf, font size 14
        >>> engine.set_font("Resources/example.otf")  # Loads example.ttf from project's Resources folder
        >>> # engine.set_font("example.vlw")          # Raises AssertionError; only supports .ttf and .otf extensions

        :raises:
        AssertionError if font has an extension different from the supported .ttf or .otf.
        """
        assert isinstance(font, str), "[ENGINE ERROR] Font name must be a string."
        assert isinstance(font_size,
                          int) and 1 <= font_size <= 200, "[ENGINE ERROR] Font size must be an integer between 1 and 200."

        valid_extensions = r'\.(ttf|otf)$'  # either .otf, .ttf or no extension (for system font)
        assert re.search(valid_extensions,
                         font) or '.' not in font, f"[ENGINE ERROR] The filename '{font}' is not a valid font file."

        if font == getattr(self, '_font_name', None) and font_size == getattr(self, '_font_size', None):
            return

        self._font_name = font
        self._font_size = font_size
        self._font_is_system = '.' not in font

        try:
            if self._font_is_system:
                self._font = pygame.font.SysFont(font, font_size)
            else:
                self._font = pygame.font.Font(font, font_size)
        except FileNotFoundError:
            print(f"[ENGINE WARNING] System font '{font}' not found, falling back to default font.")
            self._font = pygame.font.Font(None, font_size)
            self._font_name = "default"
            self._font_is_system = False
        except pygame.error as e:
            print(f"[ENGINE ERROR] Pygame error loading font '{font}': {e}, falling back to default font.")
            self._font = pygame.font.Font(None, font_size)
            self._font_name = "default"
            self._font_is_system = False

    def set_font_size(self, size: int) -> None:
        """
        Changes the font size that will be used to draw text.

        :param size: font size that will be used to draw text (positive integer)
        :return:
        :examples:
        >>> engine.set_font_size(21)  # Changes font size to 21
        """
        assert isinstance(size, int) and 1 <= size <= 200, \
            "[ENGINE ERROR] Font size must be an integer between 1 and 200."

        if size == getattr(self, '_font_size', None):  # v1.2.0 : enhance efficiency (same as current)
            return

        self._font_size = size

        if self._font_is_system:
            self._font = pygame.font.SysFont(self._font_name, size)
        else:
            self._font = pygame.font.Font(self._font_name, size)

    def draw_text(self, text: str, x: int | float, y: int | float, centered: bool = False) -> None:
        """
        Draws text using the current font and fill color.
        WARNING: if fill color is unset (None), text will not be visible.

        :param text: the text that should be drawn in the window
        :param x: x position of the text. If centered, this is the center x, otherwise this is the left.
        :param y: y position of the text. If centered, this is the center y, otherwise this is the top.
        :param centered: Optional, default = False.
                If True, text will be drawn from center. If False, text is drawn from top left.
        :return:

        :Examples:
        >>> draw_text("Hello DAE", 20, 30)          # Draws "Hello DAE", top left position is 20,30
        >>> draw_text("Hello DAE", 200, 300, True)  # Draws "Hello DAE", text is centered in position 200,300
        """
        if text is None:
            return
        if self._fill_color is None:
            print("[ENGINE WARNING] You are trying to draw text while no fill color is set, therefore it will not be visible.")
            return
        if self._font is None:
            self._font = self._default_font
            self._font_is_system = True
        text_surface = self._font.render(text, True, self._fill_color)
        text_rect = text_surface.get_rect()
        if centered:
            text_rect.center = (x, y)
        else:
            text_rect.x = x
            text_rect.y = y
        self._screen.blit(text_surface, text_rect)

    # endregion Text and fonts

    # region collision detection

    def colliding_circles(self, x: float, y: float, diameter: float, x2: float, y2: float, diameter2: float) -> bool:
        """
        Checks if two circles are colliding. The given x, y coordinates are based on the shape_mode!
        :param x: x coordinate of the first circle.
        :param y: y coordinate of the first circle.
        :param diameter: diameter of the first circle.
        :param x2: x coordinate of the second circle.
        :param y2: y coordinate of the second circle.
        :param diameter2: diameter of the second circle.
        :return: True if colliding, False if not.
        """
        pos1 = Vector2(x, y)
        pos2 = Vector2(x2, y2)
        if self._shape_mode == ShapeMode.CORNER:
            pos1.x += diameter / 2
            pos1.y += diameter / 2
            pos2.x += diameter2 / 2
            pos2.y += diameter2 / 2
        distance = math.dist((pos1.x, pos1.y), (pos2.x, pos2.y))
        return distance <= (diameter / 2 + diameter2 / 2)

    def colliding_point_in_circle(self, point_x: float, point_y: float,
                                  circle_x: float, circle_y: float, diameter: float) -> bool:
        """
        Checks if a certain point is inside a circle. The given x, y coordinates are based on the shape_mode!
        :param point_x: x coordinate of the point.
        :param point_y: y coordinate of the point.
        :param circle_x: x coordinate of the circle.
        :param circle_y: y coordinate of the circle.
        :param diameter: diameter of the circle.
        :return: True if point is in circle, False if not.
        """
        # pos = self._get_coordinates(circle_x, circle_y, diameter, diameter)
        pos = Vector2(circle_x, circle_y)
        if self._shape_mode == ShapeMode.CORNER:
            pos.x += diameter / 2
            pos.y += diameter / 2
        distance = math.sqrt(math.pow(pos.x - point_x, 2) + math.pow(pos.y - point_y, 2))
        return distance <= (diameter / 2)

    def colliding_rects(self, x: float, y: float, w: float, h: float, x2: float, y2: float, w2: float, h2: float) \
            -> bool:
        """
        Checks if two rectangles are colliding. The given x, y coordinates are based on the shape_mode!
        :param x: x coordinate of the first rectangle.
        :param y: y coordinate of the first rectangle.
        :param w: width of the first rectangle.
        :param h: height of the first rectangle.
        :param x2: x coordinate of the second rectangle.
        :param y2: y coordinate of the second rectangle.
        :param w2: diameter of the second rectangle.
        :param h2: height of the second rectangle.
        :return: True if colliding, False if not.
        """
        pos1 = self._get_coordinates(x, y, w, h)
        pos2 = self._get_coordinates(x2, y2, w2, h2)
        r1 = pygame.Rect(pos1.x, pos1.y, w, h)
        r2 = pygame.Rect(pos2.x, pos2.y, w2, h2)
        return r1.colliderect(r2)

    # v1.2.0 : changd name from pointinrect to point_in_rect for consistency
    def colliding_point_in_rect(self, point_x: float, point_y: float,
                              rect_x: float, rect_y: float, rect_w: float, rect_h: float) -> bool:
        """
        Checks if a certain point is inside a rectangle. The given x, y coordinates are based on the shape_mode!
        :param point_x: x coordinate of the point.
        :param point_y: y coordinate of the point.
        :param rect_x: x coordinate of the rectangle.
        :param rect_y: y coordinate of the rectangle.
        :param rect_w: diameter of the rectangle.
        :param rect_h: height of the rectangle.
        :return: True if point is in rectangle, False if not.
        """
        rect_pos = self._get_coordinates(rect_x, rect_y, rect_w, rect_h)
        rect = pygame.Rect(rect_pos.x, rect_pos.y, rect_w, rect_h)
        return rect.collidepoint(point_x, point_y)

    # endregion collision detection

    # v1.2.0 : removed required Resources subfolder + added requirement to avoid absolute paths
    def load_image(self, path: str) -> ProgfaImage | None:
        """
        Loads a local image (relative to your project root folder) or an online image and returns it as
        a ProgfaImage object. WARNING: Do not load images in the render or evaluate loop!

        :param path: url or local relative path starting from your project file's root folder, including filename + extension
        :return: the loaded image object, or None if loading failed.

        Examples:
        >>> img1 = engine.load_image("programmer_cat.png")   # assumes programmer_cat.png in your project root
        >>> img2 = engine.load_image("Resources/programmer_cat.png")  # loads from Resources folder
        >>> img3 = engine.load_image("https://i.pinimg.com/564x/63/92/59/6392596fe9232338735189fdd6d43bd7.jpg")
        """

        red_code = '\033[91m'
        reset_code = '\033[0m'

        path = path.strip()

        # Check if URL
        parsed_url = urlparse(path)
        if parsed_url.scheme and parsed_url.netloc:
            try:
                response = urllib.request.urlopen(path)
                image_data = BytesIO(response.read())
                image = pygame.image.load(image_data)
                return ProgfaImage(self, image)
            except Exception as e:
                print(f"{red_code}[ERROR] loading online image ({str(e)}){reset_code}")
                return None

        # Reject absolute paths
        if os.path.isabs(path):
            print(f"{red_code}[ERROR] Absolute paths are not allowed for local images: {path}")
            print(f" -> start your path from the folder your .py file is in, e.g. Resources/cat.png{reset_code}")
            return None

        # Normalize path for current OS
        norm_path = os.path.normpath(path)

        # Assume project root is current working directory (adjust if needed)
        full_path = os.path.join(os.getcwd(), norm_path)

        # Check file existence
        if not os.path.exists(full_path):
            print(f"{red_code}[ERROR] Local image file not found: {full_path}{reset_code}")
            return None

        try:
            image = pygame.image.load(full_path)
        except Exception as e:
            print(f"{red_code}[ERROR] loading local image '{full_path}' ({str(e)}){reset_code}")
            return None

        return ProgfaImage(self, image)

    # region Game-loop

    @staticmethod
    def _get_actual_key(event: pygame.event.Event) -> str:
        """Retrieves the actual key (unicode or special key)."""

        special_keys = {
            pygame.K_UP: "UP",
            pygame.K_DOWN: "DOWN",
            pygame.K_LEFT: "LEFT",
            pygame.K_RIGHT: "RIGHT",
            pygame.K_RETURN: "ENTER",
            pygame.K_KP_ENTER: "ENTER",
            pygame.K_BACKSPACE: "BACKSPACE",
            pygame.K_DELETE: "DELETE",
            pygame.K_ESCAPE: "ESCAPE",
            # v1.2.0 : extended list of special keys
            pygame.K_TAB: "TAB",
            pygame.K_LSHIFT: "LSHIFT",
            pygame.K_RSHIFT: "RSHIFT",
            pygame.K_LCTRL: "LCTRL",
            pygame.K_RCTRL: "RCTRL",
            pygame.K_LALT: "LALT",
            pygame.K_RALT: "RALT",
        }

        if event.unicode:
            return event.unicode
        return special_keys.get(event.key, "UNKNOWN_KEY")

    def shutdown(self):
        """Shuts down the game window."""
        pygame.quit()

    def play(self):
        """Starts game loop and listening to events."""
        clock = pygame.time.Clock()
        done = False

        self._setup()

        while not done:
            # ui input
            # self.delta_time = clock.tick_busy_loop(self.fps) / 1000.0
            delta_time = clock.tick(self._fps) / 1000.0


            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    done = True
                else:
                    """v1.2.0 : removing UI elements
                    self.ui_manager.process_events(event)
                    # ui input
                    if event.type == pygame.USEREVENT:
                        # Handle text input events
                        # print("user event")
                        # Handle text input events
                        if self._text_input.is_focused:
                            self._text_input.process_event(event)
                    """
                    if event.type == pygame.MOUSEMOTION:
                        self._mouse_x, self._mouse_y = event.pos
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if event.button < len(MouseButton):
                            self._mouse_button = MouseButton(event.button)
                        else:
                            self._mouse_button = MouseButton.NONE
                        self._mouse_pressed = True

                    elif event.type == pygame.MOUSEBUTTONUP:
                        self._mouse_pressed = False
                        # v1.2.0 : safer check for existing mouse button
                        if event.button in MouseButton._value2member_map_:
                            self._mouse_button = MouseButton(event.button)
                        else:
                            self._mouse_button = MouseButton.NONE
                        mouse_x, mouse_y = pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1]
                        self._mouse_pressed_event(mouse_x, mouse_y, self._mouse_button)
                        self._mouse_button = MouseButton.NONE
                    elif event.type == pygame.KEYDOWN:
                        # v1.2.0 : function to get actual key (unicode or coded)
                        actual_key = self._get_actual_key(event)

                        self._key_pressed = True
                        self._key = actual_key
                        self._key_down_event(actual_key)
                    elif event.type == pygame.KEYUP:
                        # v1.2.0 : function to get actual key (unicode or coded)
                        actual_key = self._get_actual_key(event)

                        self._key_up_event(actual_key)
                        self._key_pressed = False
                        self._key = None

            self._evaluate()
            # v1.2.0 : removing UI elements
            # self.ui_manager.update(delta_time)
            self._render()

            # Draw the UI elements
            # self.ui_manager.draw_ui(self)

            pygame.display.flip()

        self.shutdown()

    def _setup(self):
        """Executed only once at the start of the program, after initializing global variables."""
        pass

    def _evaluate(self):
        """Executed in a loop, fps times per second."""
        pass

    def _render(self):
        """Executed in a loop, fps times per second."""
        pass

    def _mouse_pressed_event(self, mouse_x: int, mouse_y: int, mouse_button: MouseButton):
        """Executed ONLY when user presses a mouse button."""
        pass

    def _key_down_event(self, key: str):
        """Executed ONLY when user presses a key down.\n
        *This function is executed automatically; never call it!*"""
        pass

    def _key_up_event(self, key: str):
        """Executed ONLY when user releases a key (so first down, then release).\n
        *This function is executed automatically; never call it!*"""
        pass

    # endregion Game-loop
