from math import trunc

import pygame
import math
import os
import re
from urllib.parse import urlparse  # image url check
import urllib.request  # image url check
from io import BytesIO  # image url check
from typing import Union  # hint for multiple possible parameter types
from typing import List, Tuple
from enum import Enum

from .progfa_image import ProgfaImage
from pygame.math import Vector2


class MouseButton(Enum):
    NONE = 0
    LEFT = 1
    MIDDLE = 2
    RIGHT = 3
    SCROLL_UP = 4
    SCROLL_DOWN = 5
    SIDE_1 = 6
    SIDE_2 = 7


class ShapeMode(Enum):
    CENTER = 0
    CORNER = 1


class ProgfaEngine:
    def __init__(self, width, height):
        self._background_color = pygame.Color(0, 0, 0, 255)  # v1.2.0 : pygame Color instead of tuple[float,float.float]
        self._outline_color = pygame.Color(255, 0, 255, 255)
        self._fill_color = pygame.Color(0, 255, 255, 255)

        self._shape_mode = ShapeMode.CORNER

        pygame.init()
        self._width = width
        self._height = height
        self._screen = pygame.display.set_mode([width, height])
        self._fps = 60

        self._mouse_x = 0
        self._mouse_y = 0
        self._mouse_pressed = False
        self._mouse_button = MouseButton.NONE

        self._key = None
        self._key_pressed = False

        self._clock = pygame.time.Clock()
        self._font_name = 'default'
        self._font_size = 20
        self._font_is_system = False
        self._font = pygame.font.Font(None, self._font_size)

        try:
            pygame.mouse.set_cursor(*pygame.cursors.diamond)
        except Exception:
            pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_ARROW)

    @property
    def width(self) -> Union[float, int]:
        return self._width

    @width.setter
    def width(self, value: Union[float, int]):
        self.set_resolution(value, self._height)
        self.background_color = self._background_color

    @property
    def height(self) -> Union[float, int]:
        return self._height

    @height.setter
    def height(self, value: Union[float, int]):
        self.set_resolution(self._width, value)
        self.background_color = self._background_color

    @property
    def fps(self) -> int:
        return self._fps

    @fps.setter
    def fps(self, value: int):
        self._fps = value

    def set_fps(self, fps: int):
        self._fps = fps

    @property
    def shape_mode(self):
        return self._shape_mode

    @shape_mode.setter
    def shape_mode(self, value: Union[ShapeMode | int]):
        assert value in (ShapeMode.CENTER, ShapeMode.CORNER, 0, 1), \
               "[ENGINE ERROR] shape_mode should be set to either ShapeMode.CENTER (0) or ShapeMode.CORNER (1)!"
        self._shape_mode = value if isinstance(value, ShapeMode) else ShapeMode(value)

    @property
    def mouse_x(self) -> float:
        return self._mouse_x

    @property
    def mouse_y(self) -> float:
        return self._mouse_y

    @property
    def mouse_pressed(self) -> bool:
        return self._mouse_pressed

    @property
    def mouse_button(self) -> MouseButton:
        return self._mouse_button

    @property
    def key_pressed(self) -> bool:
        return self._key_pressed

    @property
    def key(self) -> Union[str, None]:
        return self._key

    # v1.2.0 : replaced by property to be similar to mouse_pressed
    # def key_pressed(self) -> bool:
    #     """
    #     Returns True if a key is currently pressed, or False if no key is currently pressed.
    #     """
    #     return self._key_pressed

    def __getattr__(self, name):
        if hasattr(pygame.Surface, name):
            return getattr(self._screen, name)
        raise AttributeError(f"'ProgfaEngine' object has no attribute '{name}'")

    def set_title(self, title: str) -> None:
        pygame.display.set_caption(title)


    def set_resolution(self, width: float, height: float) -> None:
        self._width = width
        self._height = height
        self._screen = pygame.display.set_mode([width, height])

    # endregion Shape mode

    def _get_coordinates(self, x: float, y: float, width: float, height: float) -> pygame.math.Vector2:
        if self._shape_mode == ShapeMode.CENTER:
            return Vector2(x - width / 2, y - height / 2)
        else:
            return Vector2(x, y)

    # endregion Shape mode

    # region Colors

    @property
    def transparency(self) -> float:
        return self._fill_color.a / 255.0

    @transparency.setter
    def transparency(self, value: Union[float, int]):
        if self._fill_color is None:
            self._fill_color = pygame.Color(0, 0, 0)
        # Ensure the value is within the valid range (0.0 - 1.0)
        value = max(0.0, min(1.0, float(value)))
        self._fill_color.a = int(value * 255)

    @property
    def color(self) -> Union[Tuple[float, float, float, float], None]:
        if self._fill_color is None:
            return None
        r = self._fill_color.r / 255.0
        g = self._fill_color.g / 255.0
        b = self._fill_color.b / 255.0
        a = self._fill_color.a / 255.0
        return r, g, b, a

    # v1.2.0 : allow hex string as well
    @color.setter
    def color(self, value: Union[Tuple[float, float, float], Tuple[float, float, float, float], str, None]):
        if value is None:
            self._fill_color = None
            return
        elif isinstance(value, str):
            self._fill_color = self._hex_to_rgb(value)
            r, g, b, alpha = value
        elif len(value) == 3:
            r, g, b = value
            alpha = 1.0  # Default alpha value
        elif len(value) == 4:
            r, g, b, alpha = value
        else:
            raise ValueError("Invalid input tuple. Use (R, G, B) or (R, G, B, A), or a hexadecimal STR value (#FF0000).")

        # Ensure the RGB values are within the valid range (0.0 - 1.0)
        r = max(0.0, min(1.0, r))
        g = max(0.0, min(1.0, g))
        b = max(0.0, min(1.0, b))
        a = max(0.0, min(1.0, alpha))
        self._fill_color = pygame.Color(0, 0, 0)
        self._fill_color.r = int(r * 255)
        self._fill_color.g = int(g * 255)
        self._fill_color.b = int(b * 255)
        self._fill_color.a = int(a * 255)

    @property
    def background_color(self) -> Tuple[float, float, float]:
        r = self._background_color.r / 255.0
        g = self._background_color.g / 255.0
        b = self._background_color.b / 255.0
        return r, g, b

    @background_color.setter
    def background_color(self, value: Tuple[float, float, float]):
        if value is None:
            return
        elif len(value) == 3:
            r, g, b = value
        else:
            raise ValueError("Invalid input tuple. Use (R, G, B) for background color.")

        # Ensure the RGB values are within the valid range (0.0 - 1.0)
        r = max(0.0, min(1.0, r))
        g = max(0.0, min(1.0, g))
        b = max(0.0, min(1.0, b))
        self._background_color = pygame.Color(int(r * 255), int(g * 255), int(b * 255))
        self._screen.fill(self._background_color[:3])

        if value is None:
            return
        elif len(value) == 3:
            r, g, b = value
            alpha = 1.0  # Default alpha value
        elif len(value) == 4:
            r, g, b, alpha = value
        else:
            raise ValueError("Invalid input tuple for background. Use (R, G, B) or (R, G, B, A).")

        # Ensure the RGB values are within the valid range (0.0 - 1.0)
        r = max(0.0, min(1.0, r))
        g = max(0.0, min(1.0, g))
        b = max(0.0, min(1.0, b))
        a = max(0.0, min(1.0, alpha))
        self._background_color = pygame.Color(int(r * 255), int(g * 255), int(b * 255), int(a * 255))

    # v1.2.0 : property instead of function
    @property
    def has_outline(self) -> bool:
        return self._outline_color is not None and self._outline_color != (None, None, None)

    # v1.2.0 : property instead of function
    @property
    def has_fill(self) -> bool:
        return self._fill_color is not None and self._fill_color != (None, None, None)

    @property
    def outline_color(self) -> Union[Tuple[float, float, float], None]:
        if self._outline_color is None:
            return None
        r = self._outline_color.r / 255.0
        g = self._outline_color.g / 255.0
        b = self._outline_color.b / 255.0
        return r, g, b

    @outline_color.setter
    def outline_color(self, value: Union[Tuple[float, float, float], None]):
        if value is None:
            self._outline_color = None
            return
        elif len(value) == 3:
            r, g, b = value
        else:
            raise ValueError("Invalid input tuple. Use (R, G, B) for outline colors, or None to remove it.")

        # Ensure the RGB values are within the valid range (0.0 - 1.0)
        r = max(0.0, min(1.0, r))
        g = max(0.0, min(1.0, g))
        b = max(0.0, min(1.0, b))
        self._outline_color = pygame.Color(0, 0, 0)
        self._outline_color.r = int(r * 255)
        self._outline_color.g = int(g * 255)
        self._outline_color.b = int(b * 255)

    # endregion Colors

    # region Color helpers

    # v1.2.0 : moved inside class, static method
    @staticmethod
    def _hex_to_rgb(hex_color: str) -> Tuple[int, int, int, int]:
        assert isinstance(hex_color, str), '[ENGINE ERROR] hex_color should be a string (e.g. "#FF0000")!'

        hex_value = hex_color.lstrip('#')
        length = len(hex_value)

        assert length in (6, 8), "[ENGINE ERROR] Hex color must have 6 or 8 digits (e.g. #FF0000 or #FF000080)"
        assert re.fullmatch(r'[0-9A-Fa-f]{6,8}', hex_value), "[ENGINE ERROR] Invalid hex characters"

        r = int(hex_value[0:2], 16)
        g = int(hex_value[2:4], 16)
        b = int(hex_value[4:6], 16)
        a = int(hex_value[6:8], 16) if length == 8 else 255

        return r, g, b, a

    @staticmethod
    def _is_decimal_percentage(value) -> bool:
        if not isinstance(value, (float, int)):
            return False
        if not 0 <= value <= 1:
            return False
        return True

    # endregion Color helpers

    # region Draw basic shapes

    def draw_dot(self, x: Union[int, float], y: Union[int, float], outline_width: int = 1) -> None:
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.circle(self._screen, self._outline_color, (x, y), outline_width)

    def draw_circle(self, x: Union[int, float], y: Union[int, float], diameter: Union[int, float],
                    outline_width: int = 1) -> None:
        self.draw_ellipse(x, y, diameter, diameter, outline_width)

    def draw_ellipse(self, x: Union[int, float], y: Union[int, float],
                     width: Union[int, float], height: Union[int, float], outline_width: int = 1) -> None:
        if width < 0:
            x += width
            width = -width
        if height < 0:
            y += height
            height = -height

        coordinates = self._get_coordinates(x, y, width, height)
        rect = pygame.Rect(coordinates.x, coordinates.y, width, height)
        if self.has_fill:
            fill_surface = pygame.Surface(rect.size, pygame.SRCALPHA)
            pygame.draw.ellipse(fill_surface, self._fill_color, fill_surface.get_rect())
            self._screen.blit(fill_surface, (coordinates.x, coordinates.y))
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.ellipse(self._screen, self._outline_color, rect, outline_width)

    def draw_arc(self, x: Union[int, float], y: Union[int, float], width: Union[int, float], height: Union[int, float],
                 start_angle: Union[int, float], end_angle: Union[int, float], outline_width: int = 1) -> None:
        if height is None:
            height = width

        # v1.2.0 : Also accept negative width / height
        if width < 0:
            x += width
            width = -width
        if height < 0:
            y += height
            height = -height

        coordinates = self._get_coordinates(x, y, width, height)

        if self.has_fill:
            angle_range = end_angle - start_angle
            if angle_range < 0:
                angle_range += 360
            num_segments = int(angle_range / 3)  # Adjust the number of segments as desired

            # Calculate the angle step size for each triangle
            angle_step = math.radians((end_angle - start_angle) / num_segments)
            current_angle = math.radians(start_angle)

            # Iterate through the segments and draw triangles to approximate the filled arc
            for _ in range(num_segments):
                x1 = coordinates.x + width // 2
                y1 = coordinates.y + height // 2
                x2 = coordinates.x + width // 2 + int(math.cos(current_angle) * width / 2)
                y2 = coordinates.y + height // 2 + int(math.sin(current_angle) * height / 2)
                x3 = coordinates.x + width // 2 + int(math.cos(current_angle + angle_step) * width / 2)
                y3 = coordinates.y + height // 2 + int(math.sin(current_angle + angle_step) * height / 2)

                pygame.draw.polygon(self._screen, self._fill_color, [(x1, y1), (x2, y2), (x3, y3)])

                current_angle += angle_step
        # Draw the stroke of the arc
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            start_rad = math.radians(start_angle)
            end_rad = math.radians(end_angle)
            # pygame.draw.arc(self.screen, self.stroke_color, rect, start_rad, end_rad, 4)
            num_segments = int(abs(end_angle - start_angle) / 10)  # Adjust the number of segments as desired

            # Calculate the angle step size for each segment
            angle_step = math.radians((end_angle - start_angle) / num_segments)
            current_angle = math.radians(start_angle)

            center_x = coordinates.x + width // 2
            center_y = coordinates.y + height // 2

            # Iterate through the segments and draw lines to approximate the arc with a thicker stroke
            for _ in range(num_segments):
                start_x = center_x + int(math.cos(current_angle) * (width + 1) / 2)
                start_y = center_y + int(math.sin(current_angle) * (height + 1) / 2)
                end_x = center_x + int(math.cos(current_angle + angle_step) * (width + 1) / 2)
                end_y = center_y + int(math.sin(current_angle + angle_step) * (height + 1) / 2)

                pygame.draw.line(self._screen, self._outline_color, (start_x, start_y), (end_x, end_y), outline_width)

                current_angle += angle_step

            # Connect the stroke to the center
            start_x = center_x + int(math.cos(start_rad) * (width + 1) / 2)
            start_y = center_y + int(math.sin(start_rad) * (height + 1) / 2)
            end_x = center_x + int(math.cos(end_rad) * (width + 1) / 2)
            end_y = center_y + int(math.sin(end_rad) * (height + 1) / 2)
            pygame.draw.line(self._screen, self._outline_color, (center_x, center_y), (start_x, start_y), outline_width)
            pygame.draw.line(self._screen, self._outline_color, (center_x, center_y), (end_x, end_y), outline_width)

    def draw_square(self, x: Union[int, float], y: Union[int, float], size: Union[int, float],
                    outline_width: int = 1) -> None:
        self.draw_rectangle(x, y, size, size, outline_width)

    def draw_rectangle(self, x: Union[int, float], y: Union[int, float],
                       width: Union[int, float], height: Union[int, float], outline_width=1) -> None:
        if width < 0:
            x += width
            width = -width
        if height < 0:
            y += height
            height = -height

        coordinates = self._get_coordinates(x, y, width, height)
        rect = pygame.Rect(coordinates.x, coordinates.y, width, height)
        if self.has_fill:
            fill_surface = pygame.Surface(rect.size, pygame.SRCALPHA)
            pygame.draw.rect(fill_surface, self._fill_color, fill_surface.get_rect())
            self._screen.blit(fill_surface, (coordinates.x, coordinates.y))
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.rect(self._screen, self._outline_color, rect, outline_width)

    def draw_triangle(self, x1: Union[int, float], y1: Union[int, float], x2: Union[int, float], y2: Union[int, float],
                      x3: Union[int, float], y3: Union[int, float], outline_width: int = 1) -> None:
        vertices = [(x1, y1),
                    (x2, y2),
                    (x3, y3)]
        self.draw_poly(vertices, outline_width)

    def draw_quad(self, x1: Union[float, int], y1: Union[float, int], x2: Union[float, int], y2: Union[float, int],
                  x3: Union[float, int], y3: Union[float, int], x4: Union[float, int], y4: Union[float, int],
                  outline_width: int = 1) -> None:
        vertices = [(x1, y1),
                    (x2, y2),
                    (x3, y3),
                    (x4, y4)]
        self.draw_poly(vertices, outline_width)

    def draw_poly(self, vertices: List[Tuple[float, float]], outline_width: int = 1) -> None:
        if self.has_fill:
            min_x = min(vertices, key=lambda vertex: vertex[0])[0]
            max_x = max(vertices, key=lambda vertex: vertex[0])[0]
            min_y = min(vertices, key=lambda vertex: vertex[1])[1]
            max_y = max(vertices, key=lambda vertex: vertex[1])[1]
            width = max_x - min_x
            height = max_y - min_y
            fill_surface = pygame.Surface((width, height), pygame.SRCALPHA)
            adjusted_vertices = [(x - min_x, y - min_y) for x, y in vertices]
            pygame.draw.polygon(fill_surface, self._fill_color, adjusted_vertices)
            self._screen.blit(fill_surface, (min_x, min_y))
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.polygon(self._screen, self._outline_color, vertices, outline_width)

    def draw_line(self, x1: Union[int, float], y1: Union[int, float], x2: Union[int, float], y2: Union[int, float],
                  outline_width: int = 1) -> None:
        if self.has_outline and outline_width > 0:  # v1.2.0 : outline width 0 = no outline instead of crash
            pygame.draw.line(self._screen, self._outline_color, (x1, y1), (x2, y2), outline_width)

    # endregion Draw basic shapes

    def take_screenshot(self, filename: str) -> None:
        valid_extensions = {"png", "jpg", "jpeg", "bmp", "tga"}
        if not re.match(r".*\.[a-zA-Z]{3,4}$", filename):  # did they not provide an extension?
            filename = f"{filename}.png"  # png by default
        else:
            # Extract the extension (case-insensitive) and check if it's in valid extensions
            extension = filename.split('.')[-1].lower()
            if extension not in valid_extensions:
                raise ValueError(f"Unsupported file format: '{filename}' is not a valid image format.")

        # Ensure the screenshots directory exists
        screenshots_dir = "screenshots"
        if not os.path.exists(screenshots_dir):
            os.makedirs(screenshots_dir)

        # Save the screenshot in the screenshots directory
        filepath = os.path.join(screenshots_dir, filename)
        pygame.image.save(self._screen, filepath)
        print(f"-> Screenshot saved as {filepath}.")

    # region Text and fonts

    def set_font(self, font: str, font_size: int = 20) -> None:
        assert isinstance(font, str), "[ENGINE ERROR] Font name must be a string."
        assert isinstance(font_size,
                          int) and 1 <= font_size <= 200, "[ENGINE ERROR] Font size must be an integer between 1 and 200."

        valid_extensions = r'\.(ttf|otf)$'  # either .otf, .ttf or no extension (for system font)
        assert re.search(valid_extensions,
                         font) or '.' not in font, f"[ENGINE ERROR] The filename '{font}' is not a valid font file."

        if font == getattr(self, '_font_name', None) and font_size == getattr(self, '_font_size', None):
            return

        self._font_name = font
        self._font_size = font_size
        self._font_is_system = '.' not in font

        try:
            if self._font_is_system:
                self._font = pygame.font.SysFont(font, font_size)
            else:
                self._font = pygame.font.Font(font, font_size)
        except FileNotFoundError:
            print(f"[ENGINE WARNING] System font '{font}' not found, falling back to default font.")
            self._font = pygame.font.Font(None, font_size)
            self._font_name = "default"
            self._font_is_system = False
        except pygame.error as e:
            print(f"[ENGINE ERROR] Pygame error loading font '{font}': {e}, falling back to default font.")
            self._font = pygame.font.Font(None, font_size)
            self._font_name = "default"
            self._font_is_system = False

    def set_font_size(self, size: int) -> None:
        assert isinstance(size, int) and 1 <= size <= 200, \
            "[ENGINE ERROR] Font size must be an integer between 1 and 200."

        if size == getattr(self, '_font_size', None):  # v1.2.0 : enhance efficiency (same as current)
            return

        self._font_size = size

        if self._font_is_system:
            self._font = pygame.font.SysFont(self._font_name, size)
        else:
            self._font = pygame.font.Font(self._font_name, size)

    def draw_text(self, text: str, x: Union[float, int], y: Union[float, int], centered: bool = False) -> None:
        if text is None:
            return
        if self._fill_color is None:
            print("[ENGINE WARNING] You are trying to draw text while no fill color is set, therefore it will not be visible.")
            return
        if self._font is None:
            self._font = self._default_font
            self._font_is_system = True
        text_surface = self._font.render(text, True, self._fill_color)
        text_rect = text_surface.get_rect()
        if centered:
            text_rect.center = (x, y)
        else:
            text_rect.x = x
            text_rect.y = y
        self._screen.blit(text_surface, text_rect)

    # endregion Text and fonts

    # region collision detection

    def colliding_circles(self, x: float, y: float, diameter: float, x2: float, y2: float, diameter2: float) -> bool:
        pos1 = Vector2(x, y)
        pos2 = Vector2(x2, y2)
        if self._shape_mode == ShapeMode.CORNER:
            pos1.x += diameter / 2
            pos1.y += diameter / 2
            pos2.x += diameter2 / 2
            pos2.y += diameter2 / 2
        distance = math.dist((pos1.x, pos1.y), (pos2.x, pos2.y))
        return distance <= (diameter / 2 + diameter2 / 2)

    def colliding_point_in_circle(self, point_x: float, point_y: float,
                                  circle_x: float, circle_y: float, diameter: float) -> bool:
        pos = Vector2(circle_x, circle_y)
        if self._shape_mode == ShapeMode.CORNER:
            pos.x += diameter / 2
            pos.y += diameter / 2
        distance = math.sqrt(math.pow(pos.x - point_x, 2) + math.pow(pos.y - point_y, 2))
        return distance <= (diameter / 2)

    def colliding_rects(self, x: float, y: float, w: float, h: float, x2: float, y2: float, w2: float, h2: float) \
            -> bool:
        pos1 = self._get_coordinates(x, y, w, h)
        pos2 = self._get_coordinates(x2, y2, w2, h2)
        r1 = pygame.Rect(pos1.x, pos1.y, w, h)
        r2 = pygame.Rect(pos2.x, pos2.y, w2, h2)
        return r1.colliderect(r2)

    # v1.2.0 : changd name from pointinrect to point_in_rect for consistency
    def colliding_point_in_rect(self, point_x: float, point_y: float,
                              rect_x: float, rect_y: float, rect_w: float, rect_h: float) -> bool:
        rect_pos = self._get_coordinates(rect_x, rect_y, rect_w, rect_h)
        rect = pygame.Rect(rect_pos.x, rect_pos.y, rect_w, rect_h)
        return rect.collidepoint(point_x, point_y)

    # endregion collision detection

    def load_image(self, path: str) -> Union[ProgfaImage, None]:
        red_code = '\033[91m'
        reset_code = '\033[0m'

        path = path.strip()

        # Check if URL
        parsed_url = urlparse(path)
        if parsed_url.scheme and parsed_url.netloc:
            try:
                response = urllib.request.urlopen(path)
                image_data = BytesIO(response.read())
                image = pygame.image.load(image_data)
                return ProgfaImage(self, image)
            except Exception as e:
                print(f"{red_code}[ERROR] loading online image ({str(e)}){reset_code}")
                return None

        # Reject absolute paths
        if os.path.isabs(path):
            print(f"{red_code}[ERROR] Absolute paths are not allowed for local images: {path}")
            print(f" -> start your path from the folder your .py file is in, e.g. Resources/cat.png{reset_code}")
            return None

        # Normalize path for current OS
        norm_path = os.path.normpath(path)

        # Assume project root is current working directory (adjust if needed)
        full_path = os.path.join(os.getcwd(), norm_path)

        # Check file existence
        if not os.path.exists(full_path):
            print(f"{red_code}[ERROR] Local image file not found: {full_path}{reset_code}")
            return None

        try:
            image = pygame.image.load(full_path)
        except Exception as e:
            print(f"{red_code}[ERROR] loading local image '{full_path}' ({str(e)}){reset_code}")
            return None

        return ProgfaImage(self, image)

    # region Game-loop

    def play(self):
        """Starts game loop and listening to events."""
        clock = pygame.time.Clock()
        done = False

        self._setup()

        while not done:
            delta_time = clock.tick(self._fps) / 1000.0

            special_keys = {
                pygame.K_UP:        "UP",
                pygame.K_DOWN:      "DOWN",
                pygame.K_LEFT:      "LEFT",
                pygame.K_RIGHT:     "RIGHT",
                pygame.K_RETURN:    "ENTER",
                pygame.K_KP_ENTER:  "ENTER",
                pygame.K_BACKSPACE: "BACKSPACE",
                pygame.K_DELETE:    "DELETE",
                pygame.K_ESCAPE:    "ESCAPE",
                pygame.K_LSHIFT:    "LSHIFT",
                pygame.K_RSHIFT:    "RSHIFT"
            }

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    done = True
                else:
                    if event.type == pygame.MOUSEMOTION:
                        self._mouse_x, self._mouse_y = event.pos
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        if event.button < len(MouseButton):
                            self._mouse_button = MouseButton(event.button)
                        else:
                            self._mouse_button = MouseButton.NONE
                        self._mouse_pressed = True

                    elif event.type == pygame.MOUSEBUTTONUP:
                        self._mouse_pressed = False
                        if event.button < len(MouseButton):
                            self._mouse_button = MouseButton(event.button)
                        else:
                            self._mouse_button = MouseButton.NONE
                        mouse_x, mouse_y = pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1]
                        self._mouse_pressed_event(mouse_x, mouse_y, self._mouse_button)
                        self._mouse_button = MouseButton.NONE
                    elif event.type == pygame.KEYDOWN:
                        if event.key in special_keys.keys() or not event.unicode:
                            actual_key = special_keys.get(event.key, "UNKNOWN_KEY")
                        else:
                            actual_key = event.unicode

                        self._key_pressed = True
                        self._key = actual_key
                        self._key_down_event(actual_key)
                    elif event.type == pygame.KEYUP:
                        if event.key in special_keys.keys() or not event.unicode:
                            actual_key = special_keys.get(event.key, "UNKNOWN_KEY")
                        else:
                            actual_key = event.unicode

                        self._key_up_event(actual_key)
                        self._key_pressed = False
                        self._key = None

            self._evaluate()
            self._render()

            pygame.display.flip()

        pygame.quit()

    def _setup(self):
        """Executed only once at the start of the program, after initializing global variables."""
        pass

    def _evaluate(self):
        """Executed in a loop, fps times per second."""
        pass

    def _render(self):
        """Executed in a loop, fps times per second."""
        pass

    def _mouse_pressed_event(self, mouse_x: int, mouse_y: int, mouse_button: MouseButton):
        """Executed ONLY when user presses a mouse button."""
        pass

    def _key_down_event(self, key: str):
        """Executed ONLY when user presses a key down.\n
        *This function is executed automatically; never call it!*"""
        pass

    def _key_up_event(self, key: str):
        """Executed ONLY when user releases a key (so first down, then release).\n
        *This function is executed automatically; never call it!*"""
        pass

    # endregion Game-loop
